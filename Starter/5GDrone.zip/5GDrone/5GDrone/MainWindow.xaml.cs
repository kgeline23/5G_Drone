﻿using _5GDrone.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _5GDrone
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public DroneClient droneClient;
        private string msgSend;

        public MainWindow(DroneClient droneClient)
        {
            InitializeComponent();
            this.droneClient = droneClient;
            this.KeyDown += new KeyEventHandler(MainWindow_KeyDown);
        }
        void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.W:
                    msgSend = "FORWARDS";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.S:
                    msgSend = "BACKWARDS";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.A:
                    msgSend = "MOVELEFT";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.D:
                    msgSend = "MOVERIGHT";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.E:
                    msgSend = "TURNRIGHT";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.Q:
                    msgSend = "TURNLEFT";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.X:
                    msgSend = "UP";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.C:
                    msgSend = "DOWN";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.H:
                    msgSend = "HOVER";

                    droneClient.Transmit(msgSend);
                    break;

                case Key.F:
                    msgSend = "STOP";

                    droneClient.Transmit(msgSend);
                    break;

                default:
                    break;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            msgSend = "TAKEOFF";

            droneClient.Transmit(msgSend);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            msgSend = "LAND";

            droneClient.Transmit(msgSend);
        }

        private void emergencyBtn_Click(object sender, RoutedEventArgs e)
        {
            msgSend = "EMERGENCY";

            droneClient.Transmit(msgSend);
        }
    }
}
